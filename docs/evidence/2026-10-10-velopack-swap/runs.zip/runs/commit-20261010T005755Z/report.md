| Round | Updater | Hold | Update.exe exit | current\ after update | Version after | "Retrying" lines | Uninstall while broken | Repair (Setup.exe --silent) | Marker in root | Marker outside root | App starts after | Final uninstall |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| C-commit | fixed, 84af7e5 | off | 0 | present | 1.0.3 | 0 | not needed | not needed | n/a | n/a | exit 0 (1.0.3) | exit 0, root gone True |
| F4-commit | fixed, 84af7e5 | ShareNone | 1 | present | 1.0.0 | 30 | not needed | not needed | n/a | n/a | exit 0 (1.0.0) | exit 0, root gone True |
| F5-commit | fixed, 84af7e5 | ShareNone | 1 | present | 1.0.0 | 30 | not needed | not needed | n/a | n/a | exit 0 (1.0.0) | exit 0, root gone True |

## C-commit
holder:
    
restarted after the update:  exit 0
root after the update (current\ excluded):
    BrowserAI.Measure.exe 400896
    current\
    measure-data\
    measure-data\marker.txt 55
    packages\
    packages\.betaId 35
    packages\.velopack_lock 0
    packages\BrowserAI.Measure-1.0.3-full.nupkg 2322455
    packages\VelopackTemp\
    Update.exe 4070912
update log, key lines (the whole slice is logs\<round>-update\velopack-log-slice.txt):
    [update:53776] [02:58:01] [INFO] Starting Velopack Updater (0.0.0-local)
    [update:53776] [02:58:01] [INFO] Applying package 1.0.3 to current: 1.0.0
    [update:53776] [02:58:01] [INFO] About to launch: 'WideString("C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current\\BrowserAI.Measure.exe")' in dir 'Some(WideString("C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current"))' with arguments: WideString("\"C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current\\BrowserAI.Measure.exe\" --veloapp-obsolete 1.0.0\0")
    [update:53776] [02:58:01] [INFO] Backing up current dir to "C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\packages\\VelopackTemp\\tmp_yxCg9QvX4ax60ZaS"
    [update:53776] [02:58:01] [INFO] Replacing current dir with "C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\packages\\VelopackTemp\\tmp_hDYWSE0FFaqiJN0e"
    [update:53776] [02:58:01] [INFO] About to launch: 'WideString("C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current\\BrowserAI.Measure.exe")' in dir 'Some(WideString("C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current"))' with arguments: WideString("\"C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current\\BrowserAI.Measure.exe\" --veloapp-updated 1.0.3\0")
    [update:53776] [02:58:01] [INFO] Removed temp dir "C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\packages\\VelopackTemp\\tmp_yxCg9QvX4ax60ZaS" in 1ms
    [update:53776] [02:58:02] [INFO] Package applied successfully.
    [update:53776] [02:58:03] [INFO] Package version 1.0.3 applied successfully.
    [update:53776] [02:58:03] [INFO] About to launch: 'WideString("C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current\\BrowserAI.Measure.exe")' in dir 'Some(WideString("C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current"))' with arguments: WideString("\"C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current\\BrowserAI.Measure.exe\" restarted --run=C-commit-update \"two words\" embedded\\\"quote trailing\\\0")
    (0 'Retrying operation' lines)
clean after the round: yes

## F4-commit
holder:
    2026-10-10T00:58:24.0063910Z ready pid=68968 created=2026-10-10T00:58:22.7765711Z tempRoot=C:\Users\<user>\AppData\Local\BrowserAI.Measure\packages\VelopackTemp version=1.0.3 hold=60s share=None preexisting=
    2026-10-10T00:58:25.4900019Z found new-version folder C:\Users\<user>\AppData\Local\BrowserAI.Measure\packages\VelopackTemp\tmp_O4eBsTU1hOKACFFg
    2026-10-10T00:58:25.4990692Z held C:\Users\<user>\AppData\Local\BrowserAI.Measure\packages\VelopackTemp\tmp_O4eBsTU1hOKACFFg\measure-lock.txt share=None attempts=1 lastError=
    2026-10-10T00:59:25.8026107Z released C:\Users\<user>\AppData\Local\BrowserAI.Measure\packages\VelopackTemp\tmp_O4eBsTU1hOKACFFg\measure-lock.txt after 60,3 s; folder exists=True; file exists=True
restarted after the update: 
root after the update (current\ excluded):
    BrowserAI.Measure.exe 400896
    current\
    measure-data\
    measure-data\marker.txt 56
    packages\
    packages\.betaId 35
    packages\.velopack_lock 0
    packages\BrowserAI.Measure-1.0.3-full.nupkg 2322455
    packages\VelopackTemp\
    packages\VelopackTemp\tmp_O4eBsTU1hOKACFFg\
    packages\VelopackTemp\tmp_O4eBsTU1hOKACFFg\measure-lock.txt 146
    packages\VelopackTemp\tmp_O4eBsTU1hOKACFFg\sq.version 519
    packages\VelopackTemp\tmp_O4eBsTU1hOKACFFg\Velopack.dll 279040
    Update.exe 4070912
update log, key lines (the whole slice is logs\<round>-update\velopack-log-slice.txt):
    [update:73056] [02:58:25] [INFO] Starting Velopack Updater (0.0.0-local)
    [update:73056] [02:58:25] [INFO] Applying package 1.0.3 to current: 1.0.0
    [update:73056] [02:58:25] [INFO] About to launch: 'WideString("C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current\\BrowserAI.Measure.exe")' in dir 'Some(WideString("C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current"))' with arguments: WideString("\"C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current\\BrowserAI.Measure.exe\" --veloapp-obsolete 1.0.0\0")
    [update:73056] [02:58:26] [INFO] Backing up current dir to "C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\packages\\VelopackTemp\\tmp_To5uGtsvvhRtciRL"
    [update:73056] [02:58:26] [INFO] Replacing current dir with "C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\packages\\VelopackTemp\\tmp_O4eBsTU1hOKACFFg"
    [update:73056] [02:58:57] [ERROR] Failed to replace current dir (Access is denied. (os error 5)), restoring the previous version...
    [update:73056] [02:58:57] [INFO] Restored the previous version to "C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current"
    [update:73056] [02:58:57] [WARN] Failed to remove temp dir "C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\packages\\VelopackTemp\\tmp_O4eBsTU1hOKACFFg" after 1ms: The process cannot access the file because it is being used by another process. (os error 32)
    [update:73056] [02:58:57] [INFO] About to launch: 'WideString("C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current\\BrowserAI.Measure.exe")' in dir 'Some(WideString("C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current"))' with arguments: WideString("\"C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current\\BrowserAI.Measure.exe\" restarted --run=F4-commit-update \"two words\" embedded\\\"quote trailing\\\0")
    [update:73056] [02:58:57] [ERROR] Apply error: Error applying package: Unable to complete the update, the previous version was restored. Try again later, or if the issue persists, restart your computer.
    [update:73056] [02:58:57] [ERROR] An error has occurred: Apply error: Error applying package: Unable to complete the update, the previous version was restored. Try again later, or if the issue persists, restart your computer.
    (30 'Retrying operation' lines)
clean after the round: yes

## F5-commit
holder:
    2026-10-10T00:59:45.4867794Z ready pid=65168 created=2026-10-10T00:59:45.1487797Z tempRoot=C:\Users\<user>\AppData\Local\BrowserAI.Measure\packages\VelopackTemp version=1.0.3 hold=60s share=None preexisting=
    2026-10-10T00:59:45.9189780Z found new-version folder C:\Users\<user>\AppData\Local\BrowserAI.Measure\packages\VelopackTemp\tmp_YsNlvXXartrY0JAj
    2026-10-10T00:59:45.9254777Z held C:\Users\<user>\AppData\Local\BrowserAI.Measure\packages\VelopackTemp\tmp_YsNlvXXartrY0JAj\measure-lock.txt share=None attempts=1 lastError=
    2026-10-10T01:00:46.1657560Z released C:\Users\<user>\AppData\Local\BrowserAI.Measure\packages\VelopackTemp\tmp_YsNlvXXartrY0JAj\measure-lock.txt after 60,2 s; folder exists=True; file exists=True
restarted after the update:  exit 0
root after the update (current\ excluded):
    BrowserAI.Measure.exe 400896
    current\
    measure-data\
    measure-data\marker.txt 56
    packages\
    packages\.betaId 35
    packages\.velopack_lock 0
    packages\BrowserAI.Measure-1.0.3-full.nupkg 2322455
    packages\VelopackTemp\
    packages\VelopackTemp\tmp_YsNlvXXartrY0JAj\
    packages\VelopackTemp\tmp_YsNlvXXartrY0JAj\measure-lock.txt 146
    packages\VelopackTemp\tmp_YsNlvXXartrY0JAj\sq.version 519
    packages\VelopackTemp\tmp_YsNlvXXartrY0JAj\Velopack.dll 279040
    Update.exe 4070912
update log, key lines (the whole slice is logs\<round>-update\velopack-log-slice.txt):
    [update:61160] [02:59:45] [INFO] Starting Velopack Updater (0.0.0-local)
    [update:61160] [02:59:45] [INFO] Applying package 1.0.3 to current: 1.0.0
    [update:61160] [02:59:45] [INFO] About to launch: 'WideString("C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current\\BrowserAI.Measure.exe")' in dir 'Some(WideString("C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current"))' with arguments: WideString("\"C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current\\BrowserAI.Measure.exe\" --veloapp-obsolete 1.0.0\0")
    [update:61160] [02:59:46] [INFO] Backing up current dir to "C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\packages\\VelopackTemp\\tmp_HpAVoy7kWvkyUGCN"
    [update:61160] [02:59:46] [INFO] Replacing current dir with "C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\packages\\VelopackTemp\\tmp_YsNlvXXartrY0JAj"
    [update:61160] [03:00:16] [ERROR] Failed to replace current dir (Access is denied. (os error 5)), restoring the previous version...
    [update:61160] [03:00:16] [INFO] Restored the previous version to "C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current"
    [update:61160] [03:00:16] [WARN] Failed to remove temp dir "C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\packages\\VelopackTemp\\tmp_YsNlvXXartrY0JAj" after 1ms: The process cannot access the file because it is being used by another process. (os error 32)
    [update:61160] [03:00:16] [INFO] About to launch: 'WideString("C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current\\BrowserAI.Measure.exe")' in dir 'Some(WideString("C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current"))' with arguments: WideString("\"C:\\Users\\<user>\\AppData\\Local\\BrowserAI.Measure\\current\\BrowserAI.Measure.exe\" restarted --run=F5-commit-update \"two words\" embedded\\\"quote trailing\\\0")
    [update:61160] [03:00:16] [ERROR] Apply error: Error applying package: Unable to complete the update, the previous version was restored. Try again later, or if the issue persists, restart your computer.
    [update:61160] [03:00:16] [ERROR] An error has occurred: Apply error: Error applying package: Unable to complete the update, the previous version was restored. Try again later, or if the issue persists, restart your computer.
    (30 'Retrying operation' lines)
clean after the round: yes
