#!/bin/bash
# Final proof: a positive control first (a task registered with the prefix must be found by both listings),
# then the cleanup, then both listings again, then every recorded process checked by pid and creation time.
cd /c/Source/SixFive7/BrowserAI/.work/step0-tasks
R=./bin/rig2/Rig.exe
echo "== cleanup of anything left under BrowserAI-measure-20261008T1411-"
$R cleanup --stamp 20261008T1411
echo "== listings after cleanup"
$R list --prefix BrowserAI-measure-
powershell.exe -NoProfile -Command "\ = @(Get-ScheduledTask | Where-Object { \.TaskName -like 'BrowserAI-measure-*' }); 'Get-ScheduledTask, all folders, name like BrowserAI-measure-*: ' + \.Count; \ | ForEach-Object { '  ' + \.TaskPath + \.TaskName }"
schtasks.exe /query /fo csv /nh 2>&1 | grep -c "BrowserAI-measure-" | sed 's/^/schtasks \/query lines naming BrowserAI-measure-: /'
echo "== processes"
$R verify-gone --stamp 20261008T1411
